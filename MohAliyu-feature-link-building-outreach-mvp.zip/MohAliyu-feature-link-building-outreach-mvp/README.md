# Link Building Outreach Software

This is a simple link building outreach software that helps you find websites and their contact information for your outreach campaigns.

## Features

*   Create outreach campaigns with a name and a Google search query.
*   Automatically find relevant websites using Google search.
*   Scrape email addresses from the found websites.
*   View a dashboard of your campaigns and opportunities.

## Setup and Installation

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    ```
2.  **Install the dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
3.  **Set the `SERPAPI_API_KEY` environment variable:**

    You need to get an API key from [SerpApi](https://serpapi.com/). Once you have your key, you can set it as an environment variable.

    On Linux or macOS:
    ```bash
    export SERPAPI_API_KEY="your_serpapi_api_key"
    ```

    On Windows:
    ```bash
    set SERPAPI_API_KEY="your_serpapi_api_key"
    ```

4.  **Run the application:**
    ```bash
    python app.py
    ```
5.  Open your browser and go to `http://127.0.0.1:5000` to use the application.
