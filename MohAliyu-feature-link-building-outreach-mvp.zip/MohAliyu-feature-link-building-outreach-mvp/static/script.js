document.getElementById('create-campaign-form').addEventListener('submit', async (event) => {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);
    const name = formData.get('name');
    const query = formData.get('query');

    const response = await fetch('/campaigns', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, query })
    });

    if (response.ok) {
        const campaign = await response.json();
        const campaignsList = document.getElementById('campaigns-list');
        const campaignElement = document.createElement('div');
        campaignElement.classList.add('campaign');

        let opportunitiesHtml = '';
        if (campaign.opportunities) {
            opportunitiesHtml += '<h4>Opportunities</h4><ul>';
            for (const op of campaign.opportunities) {
                opportunitiesHtml += `<li><a href="${op.url}" target="_blank">${op.url}</a>`;
                if (op.emails && op.emails.length > 0) {
                    opportunitiesHtml += '<ul>';
                    for (const email of op.emails) {
                        opportunitiesHtml += `<li>${email}</li>`;
                    }
                    opportunitiesHtml += '</ul>';
                }
                opportunitiesHtml += '</li>';
            }
            opportunitiesHtml += '</ul>';
        }

        campaignElement.innerHTML = `
            <h3>${campaign.name}</h3>
            <p><strong>Query:</strong> ${campaign.query}</p>
            ${opportunitiesHtml}
        `;
        campaignsList.appendChild(campaignElement);
        form.reset();
    } else {
        alert('Failed to create campaign');
    }
});
