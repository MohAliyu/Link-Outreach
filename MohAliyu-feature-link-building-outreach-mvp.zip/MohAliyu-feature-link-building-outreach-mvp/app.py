import os
import re
import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify
from serpapi import GoogleSearch

app = Flask(__name__)

campaigns = []
SERPAPI_API_KEY = os.environ.get("SERPAPI_API_KEY")

def scrape_emails_from_url(url):
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        text = soup.get_text()
        emails = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
        return list(set(emails))
    except requests.RequestException as e:
        print(f"Error fetching {url}: {e}")
        return []

@app.route('/')
def index():
    return render_template('index.html', campaigns=campaigns)

@app.route('/campaigns', methods=['POST'])
def create_campaign():
    data = request.get_json()
    campaign = {
        'name': data['name'],
        'query': data['query'],
        'opportunities': []
    }

    search_params = {
        "q": data['query'],
        "api_key": SERPAPI_API_KEY,
        "num": 10
    }
    search = GoogleSearch(search_params)
    search_results = search.get_dict()
    organic_results = search_results.get('organic_results', [])

    for result in organic_results:
        url = result.get('link')
        if url:
            emails = scrape_emails_from_url(url)
            campaign['opportunities'].append({
                'url': url,
                'emails': emails
            })

    campaigns.append(campaign)
    return jsonify(campaign), 201

if __name__ == '__main__':
    app.run(debug=True)
